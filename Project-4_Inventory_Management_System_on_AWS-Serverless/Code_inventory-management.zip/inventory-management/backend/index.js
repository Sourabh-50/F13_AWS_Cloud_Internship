const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const {
    DynamoDBDocumentClient,
    GetCommand,
    PutCommand,
    UpdateCommand,
    DeleteCommand,
    QueryCommand,
    ScanCommand,
} = require("@aws-sdk/lib-dynamodb");
const { SNSClient, PublishCommand, SubscribeCommand } = require("@aws-sdk/client-sns");
const { v4: uuidv4 } = require("uuid");

// Initialize AWS SDK v3 clients
const dynamodbClient = new DynamoDBClient({ region: process.env.AWS_REGION });
const dynamodb = DynamoDBDocumentClient.from(dynamodbClient);
const sns = new SNSClient({ region: process.env.AWS_REGION });

const INVENTORY_TABLE = process.env.INVENTORY_TABLE_NAME || "InventoryItems";
const SALES_TABLE = process.env.SALES_TABLE_NAME || "SalesTransactions";
const SNS_TOPIC_ARN = process.env.SNS_TOPIC_ARN;

// Helper function to extract user email from Cognito token
const getUserEmailFromEvent = (event) => {
    return event.requestContext?.authorizer?.claims?.email;
};

// Helper function to send CORS headers
const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers":
        "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
};

// Helper function to create response
const createResponse = (statusCode, body) => ({
    statusCode,
    headers: corsHeaders,
    body: JSON.stringify(body),
});

// Send low stock alert via SNS
const sendLowStockAlert = async (userEmail, product) => {
    try {
        // Subscribe user email to SNS topic if not already subscribed
        const subscribeCommand = new SubscribeCommand({
            TopicArn: SNS_TOPIC_ARN,
            Protocol: "email",
            Endpoint: userEmail,
        });
        await sns.send(subscribeCommand);

        // Send notification
        const publishCommand = new PublishCommand({
            Subject: `Low Stock Alert: ${product.productName}`,
            Message: `
Dear ${userEmail},

Your product "${product.productName}" (SKU: ${product.sku}) is running low on stock.

Current Stock: ${product.currentStock}
Minimum Threshold: ${product.minThreshold}
Category: ${product.category}
Brand: ${product.brand}

Please restock this item soon to avoid stockouts.

Best regards,
Inventory Management System
            `,
            TopicArn: SNS_TOPIC_ARN,
        });

        await sns.send(publishCommand);
    } catch (error) {
        console.error("Error sending SNS notification:", error);
    }
};

// GET - List all products for a user
const getProducts = async (event) => {
    try {
        const userEmail = getUserEmailFromEvent(event);
        if (!userEmail) {
            return createResponse(401, { error: "Unauthorized: User email not found" });
        }

        const command = new QueryCommand({
            TableName: INVENTORY_TABLE,
            KeyConditionExpression: "userId = :userId",
            ExpressionAttributeValues: {
                ":userId": userEmail,
            },
        });

        const result = await dynamodb.send(command);

        return createResponse(200, {
            success: true,
            data: result.Items,
        });
    } catch (error) {
        console.error("Error fetching products:", error);
        return createResponse(500, { error: "Internal server error" });
    }
};

// POST - Add new product
const addProduct = async (event) => {
    try {
        const userEmail = getUserEmailFromEvent(event);
        if (!userEmail) {
            return createResponse(401, { error: "Unauthorized: User email not found" });
        }

        const body = JSON.parse(event.body);
        const { productName, brand, sku, category, currentStock, minThreshold, unitPrice } = body;

        // Validate required fields
        if (
            !productName ||
            !brand ||
            !sku ||
            !category ||
            currentStock === undefined ||
            minThreshold === undefined ||
            !unitPrice
        ) {
            return createResponse(400, { error: "Missing required fields" });
        }

        const productId = uuidv4();
        const timestamp = new Date().toISOString();

        const item = {
            userId: userEmail,
            productId,
            productName,
            brand,
            sku,
            category,
            currentStock: parseInt(currentStock),
            minThreshold: parseInt(minThreshold),
            unitPrice: parseFloat(unitPrice),
            createdAt: timestamp,
            updatedAt: timestamp,
        };

        const command = new PutCommand({
            TableName: INVENTORY_TABLE,
            Item: item,
        });

        await dynamodb.send(command);

        return createResponse(201, {
            success: true,
            message: "Product added successfully",
            data: item,
        });
    } catch (error) {
        console.error("Error adding product:", error);
        return createResponse(500, { error: "Internal server error" });
    }
};

// PUT - Update product
const updateProduct = async (event) => {
    try {
        const userEmail = getUserEmailFromEvent(event);
        if (!userEmail) {
            return createResponse(401, { error: "Unauthorized: User email not found" });
        }

        const productId = event.pathParameters.productId;
        const body = JSON.parse(event.body);

        // Get current product data
        const getCommand = new GetCommand({
            TableName: INVENTORY_TABLE,
            Key: {
                userId: userEmail,
                productId,
            },
        });

        const currentProduct = await dynamodb.send(getCommand);

        if (!currentProduct.Item) {
            return createResponse(404, { error: "Product not found" });
        }

        const timestamp = new Date().toISOString();

        // Build update expression dynamically
        let updateExpression = "SET updatedAt = :updatedAt";
        const expressionAttributeValues = {
            ":updatedAt": timestamp,
        };

        Object.keys(body).forEach((key) => {
            if (key !== "userId" && key !== "productId") {
                updateExpression += `, ${key} = :${key}`;
                expressionAttributeValues[`:${key}`] =
                    key === "currentStock" || key === "minThreshold"
                        ? parseInt(body[key])
                        : key === "unitPrice"
                        ? parseFloat(body[key])
                        : body[key];
            }
        });

        const updateCommand = new UpdateCommand({
            TableName: INVENTORY_TABLE,
            Key: {
                userId: userEmail,
                productId,
            },
            UpdateExpression: updateExpression,
            ExpressionAttributeValues: expressionAttributeValues,
            ReturnValues: "ALL_NEW",
        });

        await dynamodb.send(updateCommand);

        // Check if stock is below threshold after update
        const newCurrentStock =
            body.currentStock !== undefined
                ? parseInt(body.currentStock)
                : currentProduct.Item.currentStock;
        const newMinThreshold =
            body.minThreshold !== undefined
                ? parseInt(body.minThreshold)
                : currentProduct.Item.minThreshold;

        if (newCurrentStock <= newMinThreshold) {
            const updatedProduct = {
                ...currentProduct.Item,
                ...body,
                currentStock: newCurrentStock,
                minThreshold: newMinThreshold,
            };
            await sendLowStockAlert(userEmail, updatedProduct);
        }

        return createResponse(200, {
            success: true,
            message: "Product updated successfully",
        });
    } catch (error) {
        console.error("Error updating product:", error);
        return createResponse(500, { error: "Internal server error" });
    }
};

// DELETE - Delete product
const deleteProduct = async (event) => {
    try {
        const userEmail = getUserEmailFromEvent(event);
        if (!userEmail) {
            return createResponse(401, { error: "Unauthorized: User email not found" });
        }

        const productId = event.pathParameters.productId;

        const deleteCommand = new DeleteCommand({
            TableName: INVENTORY_TABLE,
            Key: {
                userId: userEmail,
                productId,
            },
        });

        await dynamodb.send(deleteCommand);

        return createResponse(200, {
            success: true,
            message: "Product deleted successfully",
        });
    } catch (error) {
        console.error("Error deleting product:", error);
        return createResponse(500, { error: "Internal server error" });
    }
};

// POST - Record a sale
const recordSale = async (event) => {
    try {
        const userEmail = getUserEmailFromEvent(event);
        if (!userEmail) {
            return createResponse(401, { error: "Unauthorized: User email not found" });
        }

        const body = JSON.parse(event.body);
        const { productId, quantitySold, customerName, notes } = body;

        // Validate required fields
        if (!productId || !quantitySold || quantitySold <= 0) {
            return createResponse(400, {
                error: "Product ID and valid quantity sold are required",
            });
        }

        // Get product details
        const getProductCommand = new GetCommand({
            TableName: INVENTORY_TABLE,
            Key: {
                userId: userEmail,
                productId,
            },
        });

        const productResult = await dynamodb.send(getProductCommand);

        if (!productResult.Item) {
            return createResponse(404, { error: "Product not found" });
        }

        const product = productResult.Item;

        // Check if sufficient stock is available
        if (product.currentStock < quantitySold) {
            return createResponse(400, {
                error: "Insufficient stock",
                available: product.currentStock,
                requested: quantitySold,
            });
        }

        const saleId = uuidv4();
        const timestamp = new Date().toISOString();
        const saleDate = new Date().toISOString().split("T")[0]; // YYYY-MM-DD format

        // Calculate sale amount
        const saleAmount = parseFloat(product.unitPrice) * parseInt(quantitySold);

        // Create sale record
        const saleItem = {
            userId: userEmail,
            saleId,
            productId,
            productName: product.productName,
            brand: product.brand,
            sku: product.sku,
            category: product.category,
            quantitySold: parseInt(quantitySold),
            unitPrice: parseFloat(product.unitPrice),
            totalAmount: saleAmount,
            customerName: customerName || "Walk-in Customer",
            notes: notes || "",
            saleDate,
            createdAt: timestamp,
        };

        // Save sale record
        const putSaleCommand = new PutCommand({
            TableName: SALES_TABLE,
            Item: saleItem,
        });

        await dynamodb.send(putSaleCommand);

        // Update product stock
        const newStock = product.currentStock - quantitySold;
        const updateStockCommand = new UpdateCommand({
            TableName: INVENTORY_TABLE,
            Key: {
                userId: userEmail,
                productId,
            },
            UpdateExpression: "SET currentStock = :newStock, updatedAt = :updatedAt",
            ExpressionAttributeValues: {
                ":newStock": newStock,
                ":updatedAt": timestamp,
            },
        });

        await dynamodb.send(updateStockCommand);

        // Check if stock is below threshold after sale
        if (newStock <= product.minThreshold) {
            const updatedProduct = {
                ...product,
                currentStock: newStock,
            };
            await sendLowStockAlert(userEmail, updatedProduct);
        }

        return createResponse(201, {
            success: true,
            message: "Sale recorded successfully",
            data: {
                sale: saleItem,
                remainingStock: newStock,
            },
        });
    } catch (error) {
        console.error("Error recording sale:", error);
        return createResponse(500, { error: "Internal server error" });
    }
};

// GET - Get sales data for charts
const getSalesData = async (event) => {
    try {
        const userEmail = getUserEmailFromEvent(event);
        if (!userEmail) {
            return createResponse(401, { error: "Unauthorized: User email not found" });
        }

        const queryParams = event.queryStringParameters || {};
        const period = queryParams.period || "30"; // Default to last 30 days
        const chartType = queryParams.type || "revenue"; // revenue, quantity, products

        // Calculate date range
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(endDate.getDate() - parseInt(period));

        const startDateStr = startDate.toISOString().split("T")[0];
        const endDateStr = endDate.toISOString().split("T")[0];

        // Query sales data
        const command = new QueryCommand({
            TableName: SALES_TABLE,
            KeyConditionExpression: "userId = :userId",
            FilterExpression: "saleDate BETWEEN :startDate AND :endDate",
            ExpressionAttributeValues: {
                ":userId": userEmail,
                ":startDate": startDateStr,
                ":endDate": endDateStr,
            },
        });

        const result = await dynamodb.send(command);
        const sales = result.Items || [];

        let chartData = [];

        if (chartType === "revenue") {
            // Daily revenue chart
            const dailyRevenue = {};
            sales.forEach((sale) => {
                const date = sale.saleDate;
                dailyRevenue[date] = (dailyRevenue[date] || 0) + sale.totalAmount;
            });

            chartData = Object.entries(dailyRevenue)
                .map(([date, revenue]) => ({
                    date,
                    value: parseFloat(revenue.toFixed(2)),
                    label: `₹${revenue.toFixed(2)}`,
                }))
                .sort((a, b) => new Date(a.date) - new Date(b.date));
        } else if (chartType === "quantity") {
            // Daily quantity sold chart
            const dailyQuantity = {};
            sales.forEach((sale) => {
                const date = sale.saleDate;
                dailyQuantity[date] = (dailyQuantity[date] || 0) + sale.quantitySold;
            });

            chartData = Object.entries(dailyQuantity)
                .map(([date, quantity]) => ({
                    date,
                    value: quantity,
                    label: `${quantity} units`,
                }))
                .sort((a, b) => new Date(a.date) - new Date(b.date));
        } else if (chartType === "products") {
            // Top selling products
            const productSales = {};
            sales.forEach((sale) => {
                const key = sale.productName;
                if (!productSales[key]) {
                    productSales[key] = {
                        productName: sale.productName,
                        totalQuantity: 0,
                        totalRevenue: 0,
                    };
                }
                productSales[key].totalQuantity += sale.quantitySold;
                productSales[key].totalRevenue += sale.totalAmount;
            });

            chartData = Object.values(productSales)
                .sort((a, b) => b.totalRevenue - a.totalRevenue)
                .slice(0, 10) // Top 10 products
                .map((item) => ({
                    name: item.productName,
                    quantity: item.totalQuantity,
                    revenue: parseFloat(item.totalRevenue.toFixed(2)),
                    label: `₹${item.totalRevenue.toFixed(2)}`,
                }));
        } else if (chartType === "categories") {
            // Sales by category
            const categorySales = {};
            sales.forEach((sale) => {
                const category = sale.category;
                if (!categorySales[category]) {
                    categorySales[category] = {
                        category,
                        totalQuantity: 0,
                        totalRevenue: 0,
                    };
                }
                categorySales[category].totalQuantity += sale.quantitySold;
                categorySales[category].totalRevenue += sale.totalAmount;
            });

            chartData = Object.values(categorySales)
                .sort((a, b) => b.totalRevenue - a.totalRevenue)
                .map((item) => ({
                    name: item.category,
                    quantity: item.totalQuantity,
                    revenue: parseFloat(item.totalRevenue.toFixed(2)),
                    label: `₹${item.totalRevenue.toFixed(2)}`,
                }));
        }

        // Calculate summary statistics
        const totalRevenue = sales.reduce((sum, sale) => sum + sale.totalAmount, 0);
        const totalQuantity = sales.reduce((sum, sale) => sum + sale.quantitySold, 0);
        const totalTransactions = sales.length;
        const averageOrderValue = totalTransactions > 0 ? totalRevenue / totalTransactions : 0;

        return createResponse(200, {
            success: true,
            data: {
                chartData,
                summary: {
                    totalRevenue: parseFloat(totalRevenue.toFixed(2)),
                    totalQuantity,
                    totalTransactions,
                    averageOrderValue: parseFloat(averageOrderValue.toFixed(2)),
                    period: parseInt(period),
                    chartType,
                },
            },
        });
    } catch (error) {
        console.error("Error fetching sales data:", error);
        return createResponse(500, { error: "Internal server error" });
    }
};

// GET - Get all sales transactions
const getSales = async (event) => {
    try {
        const userEmail = getUserEmailFromEvent(event);
        if (!userEmail) {
            return createResponse(401, { error: "Unauthorized: User email not found" });
        }

        const queryParams = event.queryStringParameters || {};
        const limit = parseInt(queryParams.limit) || 50;

        const command = new QueryCommand({
            TableName: SALES_TABLE,
            KeyConditionExpression: "userId = :userId",
            ExpressionAttributeValues: {
                ":userId": userEmail,
            },
            ScanIndexForward: false, // Sort by newest first
            Limit: limit,
        });

        const result = await dynamodb.send(command);

        return createResponse(200, {
            success: true,
            data: result.Items,
        });
    } catch (error) {
        console.error("Error fetching sales:", error);
        return createResponse(500, { error: "Internal server error" });
    }
};

exports.handler = async (event) => {
    console.log("Event:", JSON.stringify(event, null, 2));

    // Handle preflight OPTIONS request
    if (event.httpMethod === "OPTIONS") {
        return createResponse(200, {});
    }

    try {
        const method = event.httpMethod;
        const path = event.path;

        switch (method) {
            case "GET":
                if (path.includes("/products") && path.includes("/chart")) {
                    return await getSalesData(event);
                } else if (path.includes("/products")) {
                    return await getProducts(event);
                } else if (path.includes("/sales")) {
                    return await getSales(event);
                }
                break;
            case "POST":
                if (path.includes("/products")) {
                    return await addProduct(event);
                } else if (path.includes("/sales")) {
                    return await recordSale(event);
                }
                break;
            case "PUT":
                if (path.includes("/products/")) {
                    return await updateProduct(event);
                }
                break;
            case "DELETE":
                if (path.includes("/products/")) {
                    return await deleteProduct(event);
                }
                break;
            default:
                return createResponse(405, { error: "Method not allowed" });
        }

        return createResponse(404, { error: "Route not found" });
    } catch (error) {
        console.error("Lambda error:", error);
        return createResponse(500, { error: "Internal server error" });
    }
};
