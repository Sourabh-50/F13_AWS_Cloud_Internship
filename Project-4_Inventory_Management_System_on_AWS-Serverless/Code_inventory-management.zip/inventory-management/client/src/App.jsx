// App.js

import { useAuth } from "react-oidc-context";
import Inventory, { signOutRedirect } from "./components/Inventory";
import "./index.css";

function App() {
    const auth = useAuth();

    if (auth.isLoading) {
        return <div>Loading...</div>;
    }

    if (auth.error) {
        return <div>Encountering error... {auth.error.message}</div>;
    }

    if (auth.isAuthenticated) {
        return <Inventory />;
    }

    return (
        <div>
            <button
                className="m-10 h-8 w-[80px] bg-blue-600 rounded flex items-center justify-center hover:bg-blue-700 transition-colors"
                onClick={() => auth.signinRedirect()}
            >
                <span className="text-white text-sm font-medium">Sign in</span>
            </button>
        </div>
    );
}

export default App;
