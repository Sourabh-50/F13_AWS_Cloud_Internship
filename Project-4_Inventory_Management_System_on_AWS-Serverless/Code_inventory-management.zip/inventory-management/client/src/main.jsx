import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { AuthProvider } from "react-oidc-context";

const cognitoAuthConfig = {
    authority: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_fHJKPALqP",
    client_id: "367n394r8542b7js1ikp8b0vrk",
    redirect_uri: "https://d3p7therz8zsvy.cloudfront.net",
    response_type: "code",
    scope: "phone openid email",
};

const root = ReactDOM.createRoot(document.getElementById("root"));

// wrap the application with AuthProvider
root.render(
    <React.StrictMode>
        <AuthProvider {...cognitoAuthConfig}>
            <App />
        </AuthProvider>
    </React.StrictMode>
);
