import React, { useState, useEffect, useCallback, useMemo } from "react";
import {
    Package,
    AlertTriangle,
    TrendingUp,
    Plus,
    Minus,
    Search,
    Bell,
    BarChart3,
    Users,
    DollarSign,
    Filter,
    Eye,
    Edit,
    Trash2,
    Download,
    Delete,
    Trash,
    ShoppingCart,
    Calendar,
    Activity,
    X,
} from "lucide-react";
import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer,
    BarChart,
    Bar,
    PieChart,
    Pie,
    Cell,
} from "recharts";
import { useAuth } from "react-oidc-context";

// Sign out function (remains the same)
export const signOutRedirect = () => {
    sessionStorage.clear();
    const clientId = "367n394r8542b7js1ikp8b0vrk"; // Replace with your actual clientId
    const logoutUri = "https://d3p7therz8zsvy.cloudfront.net"; // Replace with your actual logout URI
    const cognitoDomain = "https://ap-south-1fhjkpalqp.auth.ap-south-1.amazoncognito.com"; // Replace with your Cognito domain
    window.location.href = `${cognitoDomain}/logout?client_id=${clientId}&logout_uri=${encodeURIComponent(
        logoutUri
    )}`;
};

// Generic Modal Component (remains the same)
const Modal = ({ isOpen, onClose, title, children }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4 transition-opacity duration-300 ease-in-out">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg transform transition-all duration-300 ease-in-out scale-95 opacity-0 animate-modalShow">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-semibold text-gray-800">{title}</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
                        <X size={24} />
                    </button>
                </div>
                <div>{children}</div>
            </div>
            <style jsx>{`
                @keyframes modalShow {
                    to {
                        opacity: 1;
                        transform: scale(1);
                    }
                }
                .animate-modalShow {
                    animation: modalShow 0.3s forwards;
                }
            `}</style>
        </div>
    );
};

// Form field component - MOVED OUTSIDE InventoryManagementSystem
const FormInput = ({
    label,
    name,
    type = "text",
    value,
    onChange,
    required = false,
    placeholder,
    children,
}) => (
    <div className="mb-4">
        <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">
            {label}
            {required && <span className="text-red-500">*</span>}
        </label>
        {children || (
            <input
                type={type}
                name={name}
                id={name}
                value={value}
                onChange={onChange}
                required={required}
                placeholder={placeholder || `Enter ${label.toLowerCase()}`}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            />
        )}
    </div>
);

const InventoryManagementSystem = () => {
    const auth = useAuth();
    const API_BASE_URL = "https://b31ee3n7c6.execute-api.ap-south-1.amazonaws.com/dev"; // Your API Gateway URL

    const getAuthHeaders = useCallback(() => {
        const token = auth.user?.id_token;
        if (!token) {
            console.warn("No auth token found. User might be unauthenticated.");
            // Optionally, trigger re-authentication or sign-out
        }
        return {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
        };
    }, [auth.user]);

    const apiService = useMemo(
        () => ({
            getProducts: async () => {
                const response = await fetch(`${API_BASE_URL}/products`, {
                    method: "GET",
                    headers: getAuthHeaders(),
                });
                if (!response.ok)
                    throw new Error(`Failed to fetch products: ${response.statusText}`);
                return response.json();
            },
            addProduct: async (product) => {
                const response = await fetch(`${API_BASE_URL}/products`, {
                    method: "POST",
                    headers: getAuthHeaders(),
                    body: JSON.stringify(product),
                });
                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({}));
                    throw new Error(
                        `Failed to add product: ${errorData.error || response.statusText}`
                    );
                }
                return response.json();
            },
            updateProduct: async (productId, updates) => {
                const response = await fetch(`${API_BASE_URL}/products/${productId}`, {
                    method: "PUT",
                    headers: getAuthHeaders(),
                    body: JSON.stringify(updates),
                });
                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({}));
                    throw new Error(
                        `Failed to update product: ${errorData.error || response.statusText}`
                    );
                }
                return response.json();
            },
            deleteProduct: async (productId) => {
                const response = await fetch(`${API_BASE_URL}/products/${productId}`, {
                    method: "DELETE",
                    headers: getAuthHeaders(),
                });
                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({}));
                    throw new Error(
                        `Failed to delete product: ${errorData.error || response.statusText}`
                    );
                }
                return response.json();
            },
            recordSale: async (saleData) => {
                const response = await fetch(`${API_BASE_URL}/sales`, {
                    method: "POST",
                    headers: getAuthHeaders(),
                    body: JSON.stringify(saleData),
                });
                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({}));
                    throw new Error(
                        `Failed to record sale: ${errorData.error || response.statusText}`
                    );
                }
                return response.json();
            },
            getSales: async (limit = 50) => {
                const response = await fetch(`${API_BASE_URL}/sales?limit=${limit}`, {
                    method: "GET",
                    headers: getAuthHeaders(),
                });
                if (!response.ok) throw new Error(`Failed to fetch sales: ${response.statusText}`);
                return response.json();
            },
            getSalesData: async (period = 30, type = "revenue") => {
                const response = await fetch(
                    `${API_BASE_URL}/products/chart?period=${period}&type=${type}`,
                    {
                        method: "GET",
                        headers: getAuthHeaders(),
                    }
                );
                if (!response.ok)
                    throw new Error(`Failed to fetch sales data: ${response.statusText}`);
                return response.json();
            },
        }),
        [getAuthHeaders, API_BASE_URL] // Added API_BASE_URL as a dependency for completeness, though it's a const
    );

    const [inventory, setInventory] = useState([]);
    const [sales, setSales] = useState([]);
    const [salesData, setSalesData] = useState({ chartData: [], summary: {} });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [searchTerm, setSearchTerm] = useState("");
    const [selectedCategory, setSelectedCategory] = useState("All");
    const [showLowStockOnly, setShowLowStockOnly] = useState(false);

    const [showAddProductModal, setShowAddProductModal] = useState(false);
    const [showRecordSaleModal, setShowRecordSaleModal] = useState(false);
    const [showEditProductModal, setShowEditProductModal] = useState(false);

    const [activeTab, setActiveTab] = useState("inventory");
    const [chartPeriod, setChartPeriod] = useState(30);
    const [chartType, setChartType] = useState("revenue");

    const initialProductFormData = {
        productName: "",
        brand: "",
        sku: "",
        category: "",
        currentStock: "",
        minThreshold: "",
        unitPrice: "",
    };
    const [productFormData, setProductFormData] = useState(initialProductFormData);

    const initialSaleFormData = { productId: "", quantitySold: "", customerName: "", notes: "" };
    const [saleFormData, setSaleFormData] = useState(initialSaleFormData);

    const [productToEdit, setProductToEdit] = useState(null);

    const loadData = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            const [productsRes, salesRes, salesChartRes] = await Promise.all([
                apiService.getProducts(),
                apiService.getSales(),
                apiService.getSalesData(chartPeriod, chartType),
            ]);
            if (productsRes.success) setInventory(productsRes.data || []);
            else throw new Error(productsRes.error || "Failed to load products");
            if (salesRes.success) setSales(salesRes.data || []);
            else throw new Error(salesRes.error || "Failed to load sales");
            if (salesChartRes.success)
                setSalesData(salesChartRes.data || { chartData: [], summary: {} });
            else throw new Error(salesChartRes.error || "Failed to load sales data");
        } catch (err) {
            setError(err.message);
            console.error("Data loading error:", err);
        } finally {
            setLoading(false);
        }
    }, [apiService, chartPeriod, chartType]);

    useEffect(() => {
        if (auth.isAuthenticated) {
            loadData();
        } else if (auth.isLoading) {
            // Still loading, wait
        } else {
            setLoading(false);
            setError("User not authenticated. Please sign in.");
        }
    }, [auth.isAuthenticated, auth.isLoading, loadData]);

    useEffect(() => {
        if (auth.isAuthenticated) {
            const fetchSalesChartData = async () => {
                try {
                    const response = await apiService.getSalesData(chartPeriod, chartType);
                    if (response.success) {
                        setSalesData(response.data);
                    } else {
                        throw new Error(response.error || "Failed to fetch chart data");
                    }
                } catch (err) {
                    setError(err.message);
                }
            };
            fetchSalesChartData();
        }
    }, [chartPeriod, chartType, apiService, auth.isAuthenticated]);

    const totalProducts = inventory.length;
    const lowStockItems = useMemo(
        () => inventory.filter((item) => item.currentStock <= item.minThreshold),
        [inventory]
    );
    const totalStockValue = useMemo(
        () =>
            inventory.reduce(
                (sum, item) =>
                    sum + (parseFloat(item.currentStock) || 0) * (parseFloat(item.unitPrice) || 0),
                0
            ),
        [inventory]
    );

    const categories = useMemo(
        () => ["All", ...new Set(inventory.map((item) => item.category).filter(Boolean))],
        [inventory]
    );

    const filteredInventory = useMemo(
        () =>
            inventory.filter((item) => {
                const matchesSearch =
                    item.productName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    item.sku?.toLowerCase().includes(searchTerm.toLowerCase());
                const matchesCategory =
                    selectedCategory === "All" || item.category === selectedCategory;
                const matchesStockFilter =
                    !showLowStockOnly || item.currentStock <= item.minThreshold;
                return matchesSearch && matchesCategory && matchesStockFilter;
            }),
        [inventory, searchTerm, selectedCategory, showLowStockOnly]
    );

    const [notifications, setNotifications] = useState([]);
    useEffect(() => {
        const newLowStockNotifications = lowStockItems.map((item) => ({
            id: item.productId,
            type: "low-stock",
            message: `Low stock: ${item.productName} (${item.currentStock} left, threshold ${item.minThreshold})`,
            timestamp: new Date().toLocaleTimeString(),
        }));

        // Filter out notifications that are already present with the same message
        // to avoid re-adding them if only timestamp changed due to re-render.
        // A more robust solution might involve only adding when an item *becomes* low stock.
        const trulyNewNotifications = newLowStockNotifications.filter(
            (newNotif) =>
                !notifications.some(
                    (existingNotif) =>
                        existingNotif.id === newNotif.id &&
                        existingNotif.message === newNotif.message
                )
        );

        if (trulyNewNotifications.length > 0) {
            setNotifications((prevNotifications) => {
                const updatedNotifications = [...trulyNewNotifications, ...prevNotifications];
                // Keep only unique notifications by id and message, then slice
                const uniqueNotifications = updatedNotifications.reduce((acc, current) => {
                    const x = acc.find(
                        (item) => item.id === current.id && item.message === current.message
                    );
                    if (!x) {
                        return acc.concat([current]);
                    } else {
                        return acc;
                    }
                }, []);
                return uniqueNotifications.slice(0, 5);
            });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [lowStockItems]); // Deliberately not including 'notifications' to avoid loop, use functional update for setNotifications.

    const adjustStock = async (productId, adjustment) => {
        try {
            const item = inventory.find((i) => i.productId === productId);
            if (!item) return;
            const newStock = Math.max(0, parseInt(item.currentStock) + adjustment);
            await apiService.updateProduct(productId, { currentStock: newStock });
            setInventory((prev) =>
                prev.map((p) => (p.productId === productId ? { ...p, currentStock: newStock } : p))
            );
        } catch (err) {
            setError(err.message);
        }
    };

    const handleProductFormChange = (e) => {
        const { name, value } = e.target;
        setProductFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleEditProductFormChange = (e) => {
        const { name, value } = e.target;
        setProductToEdit((prev) => ({ ...prev, [name]: value }));
    };

    const handleSaleFormChange = (e) => {
        const { name, value } = e.target;
        setSaleFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleAddProduct = async (e) => {
        e.preventDefault();
        if (
            !productFormData.productName ||
            !productFormData.sku ||
            !productFormData.category ||
            !productFormData.currentStock ||
            !productFormData.minThreshold ||
            !productFormData.unitPrice
        ) {
            setError("All fields are required for adding a product.");
            return;
        }
        try {
            const response = await apiService.addProduct({
                ...productFormData,
                currentStock: parseInt(productFormData.currentStock),
                minThreshold: parseInt(productFormData.minThreshold),
                unitPrice: parseFloat(productFormData.unitPrice),
            });
            if (response.success) {
                setShowAddProductModal(false);
                setProductFormData(initialProductFormData);
                await loadData();
            } else {
                setError(response.error || "Failed to add product");
            }
        } catch (err) {
            setError(err.message);
        }
    };

    const openEditProductModal = (product) => {
        setProductToEdit({ ...product });
        setShowEditProductModal(true);
    };

    const handleUpdateProduct = async (e) => {
        e.preventDefault();
        if (!productToEdit || !productToEdit.productId) return;
        try {
            // eslint-disable-next-line no-unused-vars
            const { userId, productId, createdAt, updatedAt, ...updateData } = productToEdit;
            const payload = {
                ...updateData,
                currentStock: parseInt(updateData.currentStock),
                minThreshold: parseInt(updateData.minThreshold),
                unitPrice: parseFloat(updateData.unitPrice),
            };
            const response = await apiService.updateProduct(productId, payload);
            if (response.success) {
                setShowEditProductModal(false);
                setProductToEdit(null);
                await loadData();
            } else {
                setError(response.error || "Failed to update product");
            }
        } catch (err) {
            setError(`Failed to update product: ${err.message}`);
        }
    };

    const handleDeleteProduct = async (productId) => {
        if (window.confirm("Are you sure you want to delete this product?")) {
            try {
                const response = await apiService.deleteProduct(productId);
                if (response.success) {
                    await loadData();
                } else {
                    setError(response.error || "Failed to delete product");
                }
            } catch (err) {
                setError(err.message);
            }
        }
    };

    const handleRecordSale = async (e) => {
        e.preventDefault();
        if (
            !saleFormData.productId ||
            !saleFormData.quantitySold ||
            parseInt(saleFormData.quantitySold) <= 0
        ) {
            setError("Product and a valid quantity are required for recording a sale.");
            return;
        }
        try {
            const response = await apiService.recordSale({
                ...saleFormData,
                quantitySold: parseInt(saleFormData.quantitySold),
            });
            if (response.success) {
                setShowRecordSaleModal(false);
                setSaleFormData(initialSaleFormData);
                await loadData();
            } else {
                setError(response.error || response.message || "Failed to record sale");
            }
        } catch (err) {
            setError(err.message);
        }
    };

    const CHART_COLORS = [
        "#0088FE",
        "#00C49F",
        "#FFBB28",
        "#FF8042",
        "#8884D8",
        "#82CA9D",
        "#FF5733",
        "#C70039",
    ];

    if (!auth.isAuthenticated && !auth.isLoading) {
        return (
            <div className="flex flex-col justify-center items-center min-h-screen bg-gray-100">
                <Package className="h-16 w-16 text-blue-600 mb-4" />
                <h1 className="text-3xl font-bold text-gray-800 mb-2">InventoryCloud</h1>
                <p className="text-gray-600 mb-6">
                    Please sign in to access the inventory management system.
                </p>
                <button
                    onClick={() => auth.signinRedirect()}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg shadow-md transition duration-150 ease-in-out"
                >
                    Sign In
                </button>
                {error && <p className="text-red-500 mt-4">{error}</p>}
            </div>
        );
    }

    if (loading)
        return (
            <div className="flex justify-center items-center min-h-screen bg-gray-50">
                <div className="animate-spin rounded-full h-32 w-32 border-t-4 border-b-4 border-blue-600"></div>
            </div>
        );

    // FormInput component is now defined globally (outside this component)

    return (
        <div className="min-h-screen bg-gray-100">
            <header className="bg-white shadow-sm border-b sticky top-0 z-40">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between items-center py-4">
                        <div className="flex items-center space-x-3">
                            <Package className="h-8 w-8 text-blue-600" />
                            <h1 className="text-2xl font-bold text-gray-900">InventoryCloud</h1>
                        </div>
                        <div className="flex items-center space-x-4">
                            <div className="flex space-x-1 bg-gray-200 rounded-lg p-1">
                                {["inventory", "sales", "analytics"].map((tab) => (
                                    <button
                                        key={tab}
                                        onClick={() => setActiveTab(tab)}
                                        className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors duration-150 ${
                                            activeTab === tab
                                                ? "bg-white text-blue-600 shadow-sm"
                                                : "text-gray-600 hover:bg-gray-300"
                                        }`}
                                    >
                                        {tab === "inventory" && (
                                            <Package size={16} className="inline mr-1.5" />
                                        )}
                                        {tab === "sales" && (
                                            <ShoppingCart size={16} className="inline mr-1.5" />
                                        )}
                                        {tab === "analytics" && (
                                            <BarChart3 size={16} className="inline mr-1.5" />
                                        )}
                                        {tab.charAt(0).toUpperCase() + tab.slice(1)}
                                    </button>
                                ))}
                            </div>
                            {auth.user?.profile?.email && (
                                <span className="text-sm text-gray-600 hidden md:block">
                                    {auth.user.profile.email}
                                </span>
                            )}
                            <button
                                onClick={signOutRedirect}
                                className="bg-red-500 hover:bg-red-600 text-white px-3 py-1.5 rounded-md text-sm font-medium transition-colors duration-150"
                            >
                                Sign out
                            </button>
                        </div>
                    </div>
                </div>
            </header>

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {error && (
                    <div
                        className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md shadow"
                        role="alert"
                    >
                        <div className="flex">
                            <div className="py-1">
                                <AlertTriangle className="h-6 w-6 text-red-500 mr-3" />
                            </div>
                            <div>
                                <p className="font-bold">Error</p>
                                <p className="text-sm">{error}</p>
                            </div>
                            <button
                                onClick={() => setError(null)}
                                className="ml-auto -mx-1.5 -my-1.5 bg-red-100 text-red-500 rounded-lg focus:ring-2 focus:ring-red-400 p-1.5 hover:bg-red-200 inline-flex h-8 w-8"
                            >
                                <span className="sr-only">Dismiss</span>
                                <X size={20} />
                            </button>
                        </div>
                    </div>
                )}

                {/* Dashboard Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    {[
                        {
                            title: "Total Products",
                            value: totalProducts,
                            icon: Package,
                            color: "blue",
                        },
                        {
                            title: "Period Revenue",
                            value: `₹${(salesData.summary.totalRevenue || 0).toLocaleString(
                                undefined,
                                { minimumFractionDigits: 2, maximumFractionDigits: 2 }
                            )}`,
                            icon: DollarSign,
                            color: "green",
                        },
                        {
                            title: "Low Stock Items",
                            value: lowStockItems.length,
                            icon: AlertTriangle,
                            color: "red",
                        },
                        {
                            title: "Total Stock Value",
                            value: `₹${totalStockValue.toLocaleString(undefined, {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2,
                            })}`,
                            icon: TrendingUp,
                            color: "purple",
                        },
                    ].map((card) => (
                        <div
                            key={card.title}
                            className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300"
                        >
                            <div className="flex items-center space-x-4">
                                <div
                                    className={`p-3 rounded-full bg-${card.color}-100 text-${card.color}-600`}
                                >
                                    <card.icon size={28} />
                                </div>
                                <div>
                                    <p className="text-sm font-medium text-gray-500">
                                        {card.title}
                                    </p>
                                    <p className="text-2xl font-semibold text-gray-900">
                                        {card.value}
                                    </p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {activeTab === "inventory" && (
                    <>
                        {notifications.length > 0 && (
                            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6 rounded-md shadow">
                                <div className="flex items-center mb-2">
                                    <Bell className="h-5 w-5 text-yellow-700 mr-2" />
                                    <h3 className="text-lg font-medium text-yellow-800">
                                        Recent Stock Alerts
                                    </h3>
                                </div>
                                <div className="space-y-1">
                                    {notifications.slice(0, 3).map((n) => (
                                        <div
                                            key={`${n.id}-${n.message}`} // More unique key
                                            className="text-sm text-yellow-700 flex justify-between"
                                        >
                                            <span>{n.message}</span>
                                            <span className="text-xs text-yellow-600">
                                                {n.timestamp}
                                            </span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                                <div className="md:col-span-1 relative">
                                    <Search className="h-5 w-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                                    <input
                                        type="text"
                                        placeholder="Search products..."
                                        className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                </div>
                                <div className="flex flex-col sm:flex-row gap-4 md:col-span-2 justify-end items-center">
                                    <select
                                        className="w-full sm:w-auto px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                        value={selectedCategory}
                                        onChange={(e) => setSelectedCategory(e.target.value)}
                                    >
                                        {categories.map((category) => (
                                            <option key={category} value={category}>
                                                {category}
                                            </option>
                                        ))}
                                    </select>
                                    <label className="flex items-center space-x-2 cursor-pointer">
                                        <input
                                            type="checkbox"
                                            checked={showLowStockOnly}
                                            onChange={(e) => setShowLowStockOnly(e.target.checked)}
                                            className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                        />
                                        <span className="text-sm text-gray-700">
                                            Low stock only
                                        </span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                            <div className="px-6 py-4 border-b border-gray-200 flex flex-col sm:flex-row justify-between items-center gap-4">
                                <h2 className="text-xl font-semibold text-gray-800">
                                    Inventory Items ({filteredInventory.length})
                                </h2>
                                <div className="flex space-x-3">
                                    <button
                                        onClick={() => setShowRecordSaleModal(true)}
                                        className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center space-x-2 transition-colors duration-150"
                                    >
                                        <ShoppingCart size={18} />
                                        <span>Record Sale</span>
                                    </button>
                                    <button
                                        onClick={() => setShowAddProductModal(true)}
                                        className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 transition-colors duration-150"
                                    >
                                        <Plus size={18} />
                                        <span>Add Product</span>
                                    </button>
                                </div>
                            </div>
                            <div className="overflow-x-auto">
                                <table className="min-w-full divide-y divide-gray-200">
                                    <thead className="bg-gray-50">
                                        <tr>
                                            {[
                                                "Product",
                                                "SKU",
                                                "Category",
                                                "Current Stock",
                                                "Min Threshold",
                                                "Unit Price",
                                                "Actions",
                                            ].map((header) => (
                                                <th
                                                    key={header}
                                                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                                >
                                                    {header}
                                                </th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">
                                        {filteredInventory.length === 0 ? (
                                            <tr>
                                                <td
                                                    colSpan="7"
                                                    className="text-center py-10 text-gray-500"
                                                >
                                                    No products found.
                                                </td>
                                            </tr>
                                        ) : (
                                            filteredInventory.map((item) => (
                                                <tr
                                                    key={item.productId}
                                                    className={`${
                                                        item.currentStock <= item.minThreshold
                                                            ? "bg-red-50 hover:bg-red-100"
                                                            : "hover:bg-gray-50"
                                                    } transition-colors duration-150`}
                                                >
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <div className="text-sm font-medium text-gray-900">
                                                            {item.productName}
                                                        </div>
                                                        <div className="text-xs text-gray-500">
                                                            {item.brand}
                                                        </div>
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                                                        {item.sku}
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <span className="inline-flex px-2.5 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                                                            {item.category}
                                                        </span>
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap">
                                                        <div className="flex items-center space-x-1">
                                                            <span
                                                                className={`text-sm font-medium ${
                                                                    item.currentStock <=
                                                                    item.minThreshold
                                                                        ? "text-red-600"
                                                                        : "text-gray-900"
                                                                }`}
                                                            >
                                                                {item.currentStock}
                                                            </span>
                                                            {item.currentStock <=
                                                                item.minThreshold && (
                                                                <AlertTriangle
                                                                    className="h-4 w-4 text-red-500"
                                                                    title="Low Stock" // Changed from titleAccess
                                                                />
                                                            )}
                                                        </div>
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                                                        {item.minThreshold}
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                                                        ₹{parseFloat(item.unitPrice).toFixed(2)}
                                                    </td>
                                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                        <div className="flex items-center space-x-2">
                                                            <button
                                                                onClick={() =>
                                                                    adjustStock(item.productId, -1)
                                                                }
                                                                className="text-red-500 hover:text-red-700 p-1 rounded-full hover:bg-red-100 transition-colors"
                                                                title="Decrease Stock"
                                                                disabled={item.currentStock === 0}
                                                            >
                                                                <Minus size={16} />
                                                            </button>
                                                            <button
                                                                onClick={() =>
                                                                    adjustStock(item.productId, 1)
                                                                }
                                                                className="text-green-500 hover:text-green-700 p-1 rounded-full hover:bg-green-100 transition-colors"
                                                                title="Increase Stock"
                                                            >
                                                                <Plus size={16} />
                                                            </button>
                                                            <button
                                                                onClick={() =>
                                                                    openEditProductModal(item)
                                                                }
                                                                className="text-blue-500 hover:text-blue-700 p-1 rounded-full hover:bg-blue-100 transition-colors"
                                                                title="Edit Product"
                                                            >
                                                                <Edit size={16} />
                                                            </button>
                                                            <button
                                                                onClick={() =>
                                                                    handleDeleteProduct(
                                                                        item.productId
                                                                    )
                                                                }
                                                                className="text-gray-500 hover:text-red-700 p-1 rounded-full hover:bg-red-100 transition-colors"
                                                                title="Delete Product"
                                                            >
                                                                <Trash2 size={16} />
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </>
                )}

                {activeTab === "sales" && (
                    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                        <div className="px-6 py-4 border-b border-gray-200 flex flex-col sm:flex-row justify-between items-center gap-4">
                            <h2 className="text-xl font-semibold text-gray-800">
                                Sales Transactions ({sales.length})
                            </h2>
                            <button
                                onClick={() => setShowRecordSaleModal(true)}
                                className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center space-x-2 transition-colors duration-150"
                            >
                                <Plus size={18} />
                                <span>Record Sale</span>
                            </button>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-gray-200">
                                <thead className="bg-gray-50">
                                    <tr>
                                        {[
                                            "Product",
                                            "Customer",
                                            "Qty",
                                            "Unit Price",
                                            "Total",
                                            "Date",
                                            "Notes",
                                        ].map((header) => (
                                            <th
                                                key={header}
                                                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                            >
                                                {header}
                                            </th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-gray-200">
                                    {sales.length === 0 ? (
                                        <tr>
                                            <td
                                                colSpan="7"
                                                className="text-center py-10 text-gray-500"
                                            >
                                                No sales transactions yet.
                                            </td>
                                        </tr>
                                    ) : (
                                        sales.map((sale) => (
                                            <tr
                                                key={sale.saleId}
                                                className="hover:bg-gray-50 transition-colors duration-150"
                                            >
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm font-medium text-gray-900">
                                                        {sale.productName}
                                                    </div>
                                                    <div className="text-xs text-gray-500">
                                                        SKU: {sale.sku}
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                                                    {sale.customerName || "N/A"}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                                                    {sale.quantitySold}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                                                    ₹{parseFloat(sale.unitPrice).toFixed(2)}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">
                                                    ₹{parseFloat(sale.totalAmount).toFixed(2)}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    {new Date(sale.saleDate).toLocaleDateString()}
                                                </td>
                                                <td
                                                    className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 max-w-xs truncate"
                                                    title={sale.notes}
                                                >
                                                    {sale.notes || "N/A"}
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}

                {activeTab === "analytics" && (
                    <>
                        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
                            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
                                <h2 className="text-xl font-semibold text-gray-800">
                                    Sales Analytics
                                </h2>
                                <div className="flex gap-3">
                                    <select
                                        value={chartPeriod}
                                        onChange={(e) => setChartPeriod(Number(e.target.value))}
                                        className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 sm:text-sm"
                                    >
                                        {[
                                            { val: 7, label: "Last 7 days" },
                                            { val: 30, label: "Last 30 days" },
                                            { val: 90, label: "Last 90 days" },
                                            { val: 365, label: "Last year" },
                                        ].map((opt) => (
                                            <option key={opt.val} value={opt.val}>
                                                {opt.label}
                                            </option>
                                        ))}
                                    </select>
                                    <select
                                        value={chartType}
                                        onChange={(e) => setChartType(e.target.value)}
                                        className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 sm:text-sm"
                                    >
                                        {[
                                            { val: "revenue", label: "Revenue" },
                                            { val: "quantity", label: "Quantity Sold" },
                                            { val: "products", label: "Top Products (Revenue)" },
                                            { val: "categories", label: "Category Revenue" },
                                        ].map((opt) => (
                                            <option key={opt.val} value={opt.val}>
                                                {opt.label}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                            {[
                                {
                                    title: "Total Revenue",
                                    value: `₹${(salesData.summary.totalRevenue || 0).toLocaleString(
                                        undefined,
                                        { minimumFractionDigits: 2, maximumFractionDigits: 2 }
                                    )}`,
                                    icon: DollarSign,
                                    color: "green",
                                },
                                {
                                    title: "Total Quantity Sold",
                                    value: (salesData.summary.totalQuantity || 0).toLocaleString(),
                                    icon: ShoppingCart,
                                    color: "orange",
                                },
                                {
                                    title: "Total Transactions",
                                    value: (
                                        salesData.summary.totalTransactions || 0
                                    ).toLocaleString(),
                                    icon: Activity,
                                    color: "blue",
                                },
                                {
                                    title: "Avg. Order Value",
                                    value: `₹${(
                                        salesData.summary.averageOrderValue || 0
                                    ).toLocaleString(undefined, {
                                        minimumFractionDigits: 2,
                                        maximumFractionDigits: 2,
                                    })}`,
                                    icon: BarChart3,
                                    color: "indigo",
                                },
                            ].map((card) => (
                                <div
                                    key={card.title}
                                    className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300"
                                >
                                    <div className="flex items-center space-x-4">
                                        <div
                                            className={`p-3 rounded-full bg-${card.color}-100 text-${card.color}-600`}
                                        >
                                            <card.icon size={24} />
                                        </div>
                                        <div>
                                            <p className="text-sm font-medium text-gray-500">
                                                {card.title}
                                            </p>
                                            <p className="text-xl font-bold text-gray-900">
                                                {card.value}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="bg-white rounded-xl shadow-lg p-6">
                            <h3 className="text-lg font-semibold text-gray-800 mb-4 capitalize">
                                {chartType.replace("_", " ")} Trend (
                                {salesData.summary.periodLabel || `${chartPeriod} days`})
                            </h3>
                            {salesData.chartData && salesData.chartData.length > 0 ? (
                                <ResponsiveContainer width="100%" height={400}>
                                    {chartType === "revenue" || chartType === "quantity" ? (
                                        <LineChart
                                            data={salesData.chartData}
                                            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                                        >
                                            <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                                            <XAxis
                                                dataKey="date"
                                                stroke="#666"
                                                tickFormatter={(dateStr) =>
                                                    new Date(dateStr).toLocaleDateString(
                                                        undefined,
                                                        { month: "short", day: "numeric" }
                                                    )
                                                }
                                            />
                                            <YAxis
                                                stroke="#666"
                                                tickFormatter={(value) =>
                                                    chartType === "revenue"
                                                        ? `₹${value.toLocaleString()}`
                                                        : value.toLocaleString()
                                                }
                                            />
                                            <Tooltip
                                                formatter={(value, name) => [
                                                    chartType === "revenue"
                                                        ? `₹${parseFloat(value).toLocaleString(
                                                              undefined,
                                                              {
                                                                  minimumFractionDigits: 2,
                                                                  maximumFractionDigits: 2,
                                                              }
                                                          )}`
                                                        : parseFloat(value).toLocaleString(),
                                                    name,
                                                ]}
                                                labelFormatter={(label) =>
                                                    new Date(label).toLocaleDateString()
                                                }
                                                contentStyle={{
                                                    backgroundColor: "rgba(255, 255, 255, 0.9)",
                                                    borderRadius: "8px",
                                                    boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
                                                }}
                                            />
                                            <Legend />
                                            <Line
                                                type="monotone"
                                                dataKey="value"
                                                stroke={
                                                    chartType === "revenue" ? "#22c55e" : "#3b82f6"
                                                }
                                                strokeWidth={2}
                                                dot={{ r: 4 }}
                                                activeDot={{ r: 6 }}
                                                name={
                                                    chartType === "revenue"
                                                        ? "Revenue"
                                                        : "Quantity Sold"
                                                }
                                            />
                                        </LineChart>
                                    ) : chartType === "products" ? (
                                        <BarChart
                                            data={salesData.chartData}
                                            layout="vertical"
                                            margin={{ top: 5, right: 30, left: 150, bottom: 5 }} // Increased left margin for longer product names
                                        >
                                            <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                                            <XAxis
                                                type="number"
                                                stroke="#666"
                                                tickFormatter={(value) =>
                                                    `₹${value.toLocaleString()}`
                                                }
                                            />
                                            <YAxis
                                                dataKey="name"
                                                type="category"
                                                width={140} // Adjusted width
                                                stroke="#666"
                                                interval={0} // Show all labels if possible
                                            />
                                            <Tooltip
                                                formatter={(value, name, props) => [
                                                    `Revenue: ₹${parseFloat(
                                                        props.payload.revenue
                                                    ).toLocaleString(undefined, {
                                                        minimumFractionDigits: 2,
                                                        maximumFractionDigits: 2,
                                                    })} | Qty: ${props.payload.quantity.toLocaleString()}`,
                                                    props.payload.name,
                                                ]}
                                                contentStyle={{
                                                    backgroundColor: "rgba(255, 255, 255, 0.9)",
                                                    borderRadius: "8px",
                                                    boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
                                                }}
                                            />
                                            <Legend />
                                            <Bar
                                                dataKey="revenue"
                                                name="Total Revenue"
                                                fill="#82ca9d"
                                                barSize={20}
                                            />
                                        </BarChart>
                                    ) : chartType === "categories" ? (
                                        <PieChart>
                                            <Pie
                                                data={salesData.chartData}
                                                cx="50%"
                                                cy="50%"
                                                labelLine={false}
                                                label={({ name, percent, revenue }) =>
                                                    `${name} (${(percent * 100).toFixed(0)}%)`
                                                }
                                                outerRadius={120}
                                                fill="#8884d8"
                                                dataKey="revenue"
                                                nameKey="name"
                                            >
                                                {salesData.chartData.map((entry, index) => (
                                                    <Cell
                                                        key={`cell-${index}`}
                                                        fill={
                                                            CHART_COLORS[
                                                                index % CHART_COLORS.length
                                                            ]
                                                        }
                                                    />
                                                ))}
                                            </Pie>
                                            <Tooltip
                                                formatter={(value, name, props) => [
                                                    `₹${parseFloat(
                                                        props.payload.revenue
                                                    ).toLocaleString(undefined, {
                                                        minimumFractionDigits: 2,
                                                        maximumFractionDigits: 2,
                                                    })} (Qty: ${props.payload.quantity.toLocaleString()})`,
                                                    props.payload.name,
                                                ]}
                                                contentStyle={{
                                                    backgroundColor: "rgba(255, 255, 255, 0.9)",
                                                    borderRadius: "8px",
                                                    boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
                                                }}
                                            />
                                            <Legend />
                                        </PieChart>
                                    ) : (
                                        <p>Select a chart type to view data.</p>
                                    )}
                                </ResponsiveContainer>
                            ) : (
                                <p className="text-center text-gray-500 py-10">
                                    No data available for the selected period and chart type.
                                </p>
                            )}
                        </div>
                    </>
                )}

                {/* Add Product Modal */}
                <Modal
                    isOpen={showAddProductModal}
                    onClose={() => setShowAddProductModal(false)}
                    title="Add New Product"
                >
                    <form onSubmit={handleAddProduct}>
                        <FormInput
                            label="Product Name"
                            name="productName"
                            value={productFormData.productName}
                            onChange={handleProductFormChange}
                            required
                        />
                        <FormInput
                            label="Brand"
                            name="brand"
                            value={productFormData.brand}
                            onChange={handleProductFormChange}
                            required
                        />
                        <FormInput
                            label="SKU"
                            name="sku"
                            value={productFormData.sku}
                            onChange={handleProductFormChange}
                            required
                        />
                        <FormInput
                            label="Category"
                            name="category"
                            value={productFormData.category}
                            onChange={handleProductFormChange}
                            required
                        />
                        <FormInput
                            label="Current Stock"
                            name="currentStock"
                            type="number"
                            value={productFormData.currentStock}
                            onChange={handleProductFormChange}
                            required
                        />
                        <FormInput
                            label="Min Threshold"
                            name="minThreshold"
                            type="number"
                            value={productFormData.minThreshold}
                            onChange={handleProductFormChange}
                            required
                        />
                        <FormInput
                            label="Unit Price"
                            name="unitPrice"
                            type="number"
                            step="0.01"
                            value={productFormData.unitPrice}
                            onChange={handleProductFormChange}
                            required
                        />
                        <div className="mt-6 flex justify-end space-x-3">
                            <button
                                type="button"
                                onClick={() => setShowAddProductModal(false)}
                                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                            >
                                Cancel
                            </button>
                            <button
                                type="submit"
                                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
                            >
                                Add Product
                            </button>
                        </div>
                    </form>
                </Modal>

                {/* Edit Product Modal */}
                <Modal
                    isOpen={showEditProductModal}
                    onClose={() => {
                        setShowEditProductModal(false);
                        setProductToEdit(null);
                    }}
                    title="Edit Product"
                >
                    {productToEdit && (
                        <form onSubmit={handleUpdateProduct}>
                            <FormInput
                                label="Product Name"
                                name="productName"
                                value={productToEdit.productName}
                                onChange={handleEditProductFormChange}
                                required
                            />
                            <FormInput
                                label="Brand"
                                name="brand"
                                value={productToEdit.brand}
                                onChange={handleEditProductFormChange}
                                required
                            />
                            <FormInput
                                label="SKU"
                                name="sku"
                                value={productToEdit.sku}
                                onChange={handleEditProductFormChange}
                                required
                            />
                            <FormInput
                                label="Category"
                                name="category"
                                value={productToEdit.category}
                                onChange={handleEditProductFormChange}
                                required
                            />
                            <FormInput
                                label="Current Stock"
                                name="currentStock"
                                type="number"
                                value={productToEdit.currentStock}
                                onChange={handleEditProductFormChange}
                                required
                            />
                            <FormInput
                                label="Min Threshold"
                                name="minThreshold"
                                type="number"
                                value={productToEdit.minThreshold}
                                onChange={handleEditProductFormChange}
                                required
                            />
                            <FormInput
                                label="Unit Price"
                                name="unitPrice"
                                type="number"
                                step="0.01"
                                value={productToEdit.unitPrice}
                                onChange={handleEditProductFormChange}
                                required
                            />
                            <div className="mt-6 flex justify-end space-x-3">
                                <button
                                    type="button"
                                    onClick={() => {
                                        setShowEditProductModal(false);
                                        setProductToEdit(null);
                                    }}
                                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
                                >
                                    Update Product
                                </button>
                            </div>
                        </form>
                    )}
                </Modal>

                {/* Record Sale Modal */}
                <Modal
                    isOpen={showRecordSaleModal}
                    onClose={() => setShowRecordSaleModal(false)}
                    title="Record New Sale"
                >
                    <form onSubmit={handleRecordSale}>
                        <FormInput label="Product" name="productId" required>
                            <select
                                name="productId"
                                id="productId"
                                value={saleFormData.productId}
                                onChange={handleSaleFormChange}
                                required
                                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                            >
                                <option value="">Select a product</option>
                                {inventory.map((item) => (
                                    <option key={item.productId} value={item.productId}>
                                        {item.productName} (SKU: {item.sku}) - Stock:{" "}
                                        {item.currentStock}
                                    </option>
                                ))}
                            </select>
                        </FormInput>
                        <FormInput
                            label="Quantity Sold"
                            name="quantitySold"
                            type="number"
                            value={saleFormData.quantitySold}
                            onChange={handleSaleFormChange}
                            required
                        />
                        <FormInput
                            label="Customer Name"
                            name="customerName"
                            value={saleFormData.customerName}
                            onChange={handleSaleFormChange}
                            placeholder="Walk-in Customer (Optional)"
                        />
                        <FormInput label="Notes" name="notes">
                            <textarea
                                name="notes"
                                id="notes"
                                value={saleFormData.notes}
                                onChange={handleSaleFormChange}
                                rows="3"
                                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                placeholder="Optional sale notes"
                            ></textarea>
                        </FormInput>
                        <div className="mt-6 flex justify-end space-x-3">
                            <button
                                type="button"
                                onClick={() => setShowRecordSaleModal(false)}
                                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                            >
                                Cancel
                            </button>
                            <button
                                type="submit"
                                className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700"
                            >
                                Record Sale
                            </button>
                        </div>
                    </form>
                </Modal>
            </main>
            <footer className="text-center py-8 text-sm text-gray-500">
                © {new Date().getFullYear()} InventoryCloud. All rights reserved.
            </footer>
        </div>
    );
};

export default InventoryManagementSystem;
