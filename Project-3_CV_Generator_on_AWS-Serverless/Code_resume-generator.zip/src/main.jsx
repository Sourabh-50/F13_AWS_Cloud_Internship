// index.js
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { AuthProvider } from "react-oidc-context";
import "./index.css";

const cognitoAuthConfig = {
    authority: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_x07BMQDpN",
    client_id: "6qqu0fr9lca0kont1of0fqiqrr",
    redirect_uri: "https://d31oib4g79q3xe.cloudfront.net",
    response_type: "code",
    scope: "phone openid email",
};

const root = ReactDOM.createRoot(document.getElementById("root"));

// wrap the application with AuthProvider
root.render(
    <React.StrictMode>
        <AuthProvider {...cognitoAuthConfig}>
            <App />
        </AuthProvider>
    </React.StrictMode>
);
