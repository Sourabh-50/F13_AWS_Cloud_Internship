// App.js
import React, { useState, useRef, useEffect } from "react";
import Form from "./components/Form";
import TemplateOne from "./components/TemplateOne";
import TemplateTwo from "./components/TemplateTwo";
import html2pdf from "html2pdf.js";
import "./App.css";
import axios from "axios";

import { useAuth } from "react-oidc-context";
const REACT_APP_API_ENDPOINT = "https://xs4pqly1oh.execute-api.ap-south-1.amazonaws.com/dev/resume";

function App() {
    const auth = useAuth();

    // 1. Hold the latest form data here
    const [formData, setFormData] = useState(null);

    // 2. Track which template is selected: 'one' or 'two'
    const [selectedTemplate, setSelectedTemplate] = useState("one");

    // 3. A ref to the preview area; used for PDF generation
    const resumeRef = useRef();

    // 4. Upload states
    const [isUploading, setIsUploading] = useState(false);
    const [uploadStatus, setUploadStatus] = useState("");
    const [savedResumes, setSavedResumes] = useState([]);

    // 5. Get user email from auth
    const userEmail = auth.user?.profile?.email;

    // 6. Callback passed down to Form: whenever formData updates, store it here
    function handleDataChange(updatedData) {
        setFormData(updatedData);
    }

    // 7. Helper function to convert blob to base64
    const blobToBase64 = (blob) => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64String = reader.result.split(",")[1];
                resolve(base64String);
            };
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    };

    // 8. Upload PDF to Lambda function
    const uploadPDFToLambda = async (pdfBlob, resumeName) => {
        if (!userEmail) {
            throw new Error("User email not available");
        }

        try {
            // Convert blob to base64
            const pdfBase64 = await blobToBase64(pdfBlob);

            // Prepare payload for Lambda
            const payload = {
                email: userEmail,
                pdfBase64: pdfBase64,
                resumeName: resumeName,
                resumeData: {
                    template: selectedTemplate,
                    fullName: formData?.fullName || "",
                    tags: [
                        ...(formData?.skills
                            ? Array.isArray(formData.skills)
                                ? formData.skills.map((skill) => skill.name || skill)
                                : String(formData.skills)
                                      .split(",")
                                      .map((s) => s.trim())
                                      .filter(Boolean)
                            : []),
                        selectedTemplate === "one" ? "Template One" : "Template Two",
                    ],
                    generatedAt: new Date().toISOString(),
                    sections: {
                        hasExperience: Array.isArray(formData?.experiences)
                            ? formData.experiences.length > 0
                            : false,
                        hasEducation: Array.isArray(formData?.education)
                            ? formData.education.length > 0
                            : false,
                        hasSkills: Array.isArray(formData?.skills)
                            ? formData.skills.length > 0
                            : !!formData?.skills,
                        hasProjects: Array.isArray(formData?.projects)
                            ? formData.projects.length > 0
                            : false,
                    },
                },
            };

            // Send to Lambda via API Gateway using axios
            const response = await axios.post(REACT_APP_API_ENDPOINT, payload, {
                headers: {
                    Authorization: `Bearer ${auth.user?.id_token}`,
                },
            });

            const result = response.data;

            if (response.status === 200 && result.success) {
                return result;
            } else {
                throw new Error(result.error || "Upload failed");
            }
        } catch (error) {
            console.error("Error uploading to Lambda:", error);
            throw error;
        }
    };

    // 9. Fetch saved resumes from Lambda
    const fetchSavedResumes = async () => {
        if (!userEmail) return;

        try {
            const response = await axios.get(`${REACT_APP_API_ENDPOINT}`, {
                headers: {
                    Authorization: `Bearer ${auth.user?.id_token}`,
                },
            });

            const result = response.data;

            if (response.status === 200 && result.success) {
                setSavedResumes(result.resumes || []);
            } else {
                console.error("Failed to fetch resumes:", result.error);
            }
        } catch (error) {
            console.error("Error fetching resumes:", error);
        }
    };

    // 11. Generate PDF and upload to Lambda
    const handleSaveToCloud = async () => {
        if (!resumeRef.current || !formData || !userEmail) {
            setUploadStatus("Error: Missing required data");
            return;
        }

        setIsUploading(true);
        setUploadStatus("Generating PDF...");

        try {
            const fileName = `${(formData.fullName || "resume").replace(/\s+/g, "_")}.pdf`;
            const options = {
                margin: 0.5,
                filename: fileName,
                image: { type: "jpeg", quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: "in", format: "letter", orientation: "portrait" },
            };

            setUploadStatus("Converting to PDF...");

            // Generate PDF as blob
            const pdfBlob = await html2pdf().set(options).from(resumeRef.current).output("blob");

            setUploadStatus("Uploading to cloud...");

            // Upload to Lambda
            await uploadPDFToLambda(pdfBlob, fileName.replace(".pdf", ""));

            setUploadStatus(`Success: Resume saved to cloud!`);

            // Refresh the saved resumes list
            await fetchSavedResumes();

            // Clear status after 3 seconds
            setTimeout(() => setUploadStatus(""), 3000);
        } catch (error) {
            console.error("Error saving to cloud:", error);
            setUploadStatus(`Error: ${error.message}`);

            // Clear error after 5 seconds
            setTimeout(() => setUploadStatus(""), 5000);
        } finally {
            setIsUploading(false);
        }
    };

    // 12. Load saved resumes when user is authenticated
    useEffect(() => {
        if (auth.isAuthenticated && userEmail) {
            fetchSavedResumes();
        }
    }, [auth.isAuthenticated, userEmail]);

    const signOutRedirect = () => {
        sessionStorage.clear();
        const clientId = "6qqu0fr9lca0kont1of0fqiqrr";
        const logoutUri = "https://d31oib4g79q3xe.cloudfront.net";
        const cognitoDomain = "https://ap-south-1x07bmqdpn.auth.ap-south-1.amazoncognito.com";
        window.location.href = `${cognitoDomain}/logout?client_id=${clientId}&logout_uri=${encodeURI(
            logoutUri
        )}`;
    };

    if (auth.isLoading) {
        return <div>Loading...</div>;
    }

    if (auth.error) {
        return <div>Encountering error... {auth.error.message}</div>;
    }

    if (auth.isAuthenticated) {
        return (
            <div className="app-container">
                <div className="app-header">
                    <h1>Resume Generator</h1>
                    <div className="user-info">
                        <span>Welcome, {auth.user?.profile?.name || userEmail}</span>
                        <button onClick={signOutRedirect} className="sign-out-btn">
                            Sign Out
                        </button>
                    </div>
                </div>

                <div className="main-content">
                    {/* ── Left Pane: The Form ─────────────────────────── */}
                    <div className="left-pane">
                        <Form
                            onDataChange={handleDataChange}
                            selectedTemplate={selectedTemplate}
                            setSelectedTemplate={setSelectedTemplate}
                        />

                        {/* Action Buttons */}
                        <div className="action-buttons">
                            <button
                                className="download-btn"
                                onClick={handleSaveToCloud}
                                disabled={!formData || !formData.fullName || isUploading}
                            >
                                {isUploading ? "Saving..." : "Save to Cloud"}
                            </button>
                        </div>

                        {/* Upload Status */}
                        {uploadStatus && (
                            <div
                                className={`upload-status ${
                                    uploadStatus.startsWith("Error")
                                        ? "error"
                                        : uploadStatus.startsWith("Success")
                                        ? "success"
                                        : "info"
                                }`}
                            >
                                {uploadStatus}
                            </div>
                        )}

                        {/* Saved Resumes */}
                        {savedResumes.length > 0 && (
                            <div className="saved-resumes">
                                <div className="saved-resumes-header">
                                    <h3>Your Saved Resumes</h3>
                                    <button
                                        onClick={fetchSavedResumes}
                                        className="refresh-btn"
                                        disabled={isUploading}
                                    >
                                        Refresh
                                    </button>
                                </div>

                                <div className="resumes-list">
                                    {savedResumes.map((resume) => (
                                        <div key={resume.id} className="resume-item">
                                            <div className="resume-info">
                                                <h4>{resume.resumeName}</h4>
                                                <p className="resume-meta">
                                                    Template: {resume.template} | Created:{" "}
                                                    {new Date(
                                                        resume.createdAt
                                                    ).toLocaleDateString()}
                                                </p>
                                                {resume.tags && resume.tags.length > 0 && (
                                                    <p className="resume-tags">
                                                        Tags: {resume.tags.join(", ")}
                                                    </p>
                                                )}
                                            </div>
                                            <a
                                                href={resume.downloadUrl}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="download-link"
                                            >
                                                Download
                                            </a>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>

                    {/* ── Right Pane: Live Preview ───────────────────── */}
                    <div className="right-pane">
                        {formData ? (
                            selectedTemplate === "one" ? (
                                <div ref={resumeRef}>
                                    <TemplateOne data={formData} />
                                </div>
                            ) : (
                                <div ref={resumeRef}>
                                    <TemplateTwo data={formData} />
                                </div>
                            )
                        ) : (
                            <p>Please fill in the form to preview your resume.</p>
                        )}
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="auth-container">
            <div className="auth-content">
                <h1>Resume Generator</h1>
                <p>Please sign in to create and manage your resumes</p>
                <button onClick={() => auth.signinRedirect()} className="sign-in-btn">
                    Sign In
                </button>
            </div>
        </div>
    );
}

export default App;
