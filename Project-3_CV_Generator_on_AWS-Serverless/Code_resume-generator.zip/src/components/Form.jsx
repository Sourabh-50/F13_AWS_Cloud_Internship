// src/components/Form.js
import React, { useState, useEffect } from "react";
import "../styles/Form.css";

export default function Form({ onDataChange, selectedTemplate, setSelectedTemplate }) {
    // 1. Initialize form state
    const [formData, setFormData] = useState({
        fullName: "",
        email: "",
        phone: "",
        education: [{ institution: "", degree: "", year: "" }],
        experience: [{ company: "", title: "", duration: "", details: "" }],
        skills: "",
    });

    // 2. Whenever formData changes, notify parent component
    useEffect(() => {
        onDataChange(formData);
    }, [formData, onDataChange]);

    // 3. Handler for updating top-level fields (fullName, email, phone, skills)
    function handleTopLevelChange(e) {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    }

    // 4. Handler for updating nested fields (education[] or experience[])
    function handleNestedChange(e, section, index) {
        const { name, value } = e.target;
        setFormData((prev) => {
            // Copy the existing array (either prev.education or prev.experience)
            const items = [...prev[section]];
            // Update the specific object at "index"
            items[index] = {
                ...items[index],
                [name]: value,
            };
            return {
                ...prev,
                [section]: items,
            };
        });
    }

    // 5. Add a new empty row to "education"
    function addEducationRow() {
        setFormData((prev) => ({
            ...prev,
            education: [...prev.education, { institution: "", degree: "", year: "" }],
        }));
    }

    // 6. Add a new empty row to "experience"
    function addExperienceRow() {
        setFormData((prev) => ({
            ...prev,
            experience: [...prev.experience, { company: "", title: "", duration: "", details: "" }],
        }));
    }

    return (
        <div className="form-container">
            <h2>Resume Details</h2>

            {/* ── Full Name ───────────────────────────────────────────── */}
            <label className="form-label">
                Full Name:
                <input
                    type="text"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleTopLevelChange}
                    placeholder="John Doe"
                />
            </label>

            {/* ── Email & Phone ───────────────────────────────────────── */}
            <label className="form-label">
                Email:
                <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleTopLevelChange}
                    placeholder="john@example.com"
                />
            </label>

            <label className="form-label">
                Phone:
                <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleTopLevelChange}
                    placeholder="+1-555-123456"
                />
            </label>

            {/* ── Education Section ───────────────────────────────────── */}
            <div className="section">
                <h3>Education</h3>
                {formData.education.map((edu, idx) => (
                    <div key={idx} className="subsection">
                        <input
                            type="text"
                            name="institution"
                            placeholder="Institution"
                            value={edu.institution}
                            onChange={(e) => handleNestedChange(e, "education", idx)}
                        />
                        <input
                            type="text"
                            name="degree"
                            placeholder="Degree"
                            value={edu.degree}
                            onChange={(e) => handleNestedChange(e, "education", idx)}
                        />
                        <input
                            type="text"
                            name="year"
                            placeholder="Year (e.g., 2023)"
                            value={edu.year}
                            onChange={(e) => handleNestedChange(e, "education", idx)}
                        />
                    </div>
                ))}

                <button type="button" className="add-btn" onClick={addEducationRow}>
                    + Add Education
                </button>
            </div>

            {/* ── Experience Section ──────────────────────────────────── */}
            <div className="section">
                <h3>Work Experience</h3>
                {formData.experience.map((exp, idx) => (
                    <div key={idx} className="subsection">
                        <input
                            type="text"
                            name="company"
                            placeholder="Company"
                            value={exp.company}
                            onChange={(e) => handleNestedChange(e, "experience", idx)}
                        />
                        <input
                            type="text"
                            name="title"
                            placeholder="Title"
                            value={exp.title}
                            onChange={(e) => handleNestedChange(e, "experience", idx)}
                        />
                        <input
                            type="text"
                            name="duration"
                            placeholder="Duration (e.g., 2021–2023)"
                            value={exp.duration}
                            onChange={(e) => handleNestedChange(e, "experience", idx)}
                        />
                        <input
                            type="text"
                            name="details"
                            placeholder="Details (comma-separated)"
                            value={exp.details}
                            onChange={(e) => handleNestedChange(e, "experience", idx)}
                        />
                    </div>
                ))}

                <button type="button" className="add-btn" onClick={addExperienceRow}>
                    + Add Experience
                </button>
            </div>

            {/* ── Skills Section ───────────────────────────────────────── */}
            <label className="form-label">
                Skills (comma-separated):
                <input
                    type="text"
                    name="skills"
                    value={formData.skills}
                    onChange={handleTopLevelChange}
                    placeholder="JavaScript, React, Node.js"
                />
            </label>

            {/* ── Template Selection ───────────────────────────────────── */}
            <div className="section">
                <h3>Select Template:</h3>
                <label>
                    <input
                        type="radio"
                        name="template"
                        value="one"
                        checked={selectedTemplate === "one"}
                        onChange={(e) => setSelectedTemplate(e.target.value)}
                    />
                    Template One
                </label>

                <label>
                    <input
                        type="radio"
                        name="template"
                        value="two"
                        checked={selectedTemplate === "two"}
                        onChange={(e) => setSelectedTemplate(e.target.value)}
                    />
                    Template Two
                </label>
            </div>
        </div>
    );
}
