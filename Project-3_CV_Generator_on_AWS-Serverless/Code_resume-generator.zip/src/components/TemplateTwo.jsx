// src/components/TemplateTwo.js
import React from "react";
import "../styles/TemplateTwo.css";

export default function TemplateTwo({ data }) {
    const { fullName, email, phone, education, experience, skills } = data;

    // Helper: convert comma-separated “details” into <li> bullets
    const formatDetails = (expItem) =>
        expItem.details.split(",").map((bullet, idx) => <li key={idx}>{bullet.trim()}</li>);

    return (
        <div className="template-two">
            {/* ── Left Column: Name + Contact + Skills ───────────── */}
            <div className="t2-left-col">
                <div className="t2-profile-header">
                    <h1 className="t2-name">{fullName || "Your Name"}</h1>
                    <p className="t2-contact">{email || "you@example.com"}</p>
                    <p className="t2-contact">{phone || "123-456-7890"}</p>
                </div>

                <div className="t2-section t2-skills-section">
                    <h2 className="t2-section-title">Skills</h2>
                    <ul className="t2-skills-list">
                        {skills
                            ? skills
                                  .split(",")
                                  .map((skill, idx) => <li key={idx}>{skill.trim()}</li>)
                            : [
                                  <li key="s1">Skill1</li>,
                                  <li key="s2">Skill2</li>,
                                  <li key="s3">Skill3</li>,
                              ]}
                    </ul>
                </div>
            </div>

            {/* ── Right Column: Education + Experience ────────────── */}
            <div className="t2-right-col">
                <div className="t2-section">
                    <h2 className="t2-section-title">Education</h2>
                    {education.map((edu, idx) => (
                        <div key={idx} className="t2-edu-item">
                            <p className="t2-degree">{edu.degree || "Degree"}</p>
                            <p className="t2-institution">{edu.institution || "Institution"}</p>
                            <p className="t2-year">{edu.year || "Year"}</p>
                        </div>
                    ))}
                </div>

                <div className="t2-section">
                    <h2 className="t2-section-title">Experience</h2>
                    {experience.map((exp, idx) => (
                        <div key={idx} className="t2-exp-item">
                            <p className="t2-title">{exp.title || "Job Title"}</p>
                            <p className="t2-company">{exp.company || "Company"}</p>
                            <p className="t2-duration">{exp.duration || "Duration"}</p>
                            <ul className="t2-details">{formatDetails(exp)}</ul>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
