// src/components/TemplateOne.js
import React from "react";
import "../styles/TemplateOne.css";

export default function TemplateOne({ data }) {
    const { fullName, email, phone, education, experience, skills } = data;

    // Helper: convert comma-separated “details” into <li> bullets
    const formatDetails = (expItem) =>
        expItem.details.split(",").map((bullet, idx) => <li key={idx}>{bullet.trim()}</li>);

    return (
        <div className="template-one">
            {/* ── Header (Name + Contact) ──────────────────────── */}
            <header className="t1-header">
                <h1 className="t1-name">{fullName || "Your Name"}</h1>
                <p className="t1-contact">
                    {email || "you@example.com"} &#x2022; {phone || "123-456-7890"}
                </p>
            </header>

            {/* ── Education Section ─────────────────────────────── */}
            <section className="t1-section">
                <h2 className="t1-section-title">Education</h2>
                {education.map((edu, idx) => (
                    <div key={idx} className="t1-edu-item">
                        <p className="t1-degree">
                            {edu.degree || "Degree"} &mdash;{" "}
                            <span className="t1-year">{edu.year || "Year"}</span>
                        </p>
                        <p className="t1-institution">{edu.institution || "Institution"}</p>
                    </div>
                ))}
            </section>

            {/* ── Experience Section ───────────────────────────── */}
            <section className="t1-section">
                <h2 className="t1-section-title">Experience</h2>
                {experience.map((exp, idx) => (
                    <div key={idx} className="t1-exp-item">
                        <p className="t1-title">
                            {exp.title || "Job Title"} &mdash;{" "}
                            <span className="t1-company">{exp.company || "Company"}</span>
                        </p>
                        <p className="t1-duration">{exp.duration || "Duration"}</p>
                        <ul className="t1-details">{formatDetails(exp)}</ul>
                    </div>
                ))}
            </section>

            {/* ── Skills Section ─────────────────────────────────── */}
            <section className="t1-section">
                <h2 className="t1-section-title">Skills</h2>
                <p className="t1-skills">{skills || "Skill1, Skill2, Skill3"}</p>
            </section>
        </div>
    );
}
